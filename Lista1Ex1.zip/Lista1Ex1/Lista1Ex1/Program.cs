﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double b;
            double h;
            double A;

            Console.Write("Digite o valor da base do retângulo: ");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura do retângulo: ");
            h = double.Parse(Console.ReadLine());

            A = b * h;
            Console.WriteLine("A área do retâgulo é igual a: {0}", A); 
            




        }
    }
}
