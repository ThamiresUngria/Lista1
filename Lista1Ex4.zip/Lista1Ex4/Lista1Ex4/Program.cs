﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            double A;

            Console.Write("Digite o valor da base do triangulo: ");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura do triangulo: ");
            h = double.Parse(Console.ReadLine());

            A = (b * h) / 2;

            Console.WriteLine("A área do triangulo é: {0}", A);



        }
    }
}
