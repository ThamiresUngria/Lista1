﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            double v4;
            double Media;


            Console.Write("Digite o 1º valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 2º valor: ");
            v2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 3º valor: ");
            v3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 4º valor: ");
            v4 = double.Parse(Console.ReadLine());

            Media = (v1 + v2 + v3 + v4) / 4;

            Console.WriteLine("A média aritmética dos valores é de: {0}", Media);


        }
    }
}
